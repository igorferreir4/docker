# Import scripts

This subfolder contains scripts to import data from other systems. It is at an early stage. At present, there are examples of basic importing from the following:
* Trello
* Asana
* Notion
* Jira
* Todoist
* Nextcloud Deck

[Contribute code](https://mattermost.github.io/focalboard/) to expand this.
