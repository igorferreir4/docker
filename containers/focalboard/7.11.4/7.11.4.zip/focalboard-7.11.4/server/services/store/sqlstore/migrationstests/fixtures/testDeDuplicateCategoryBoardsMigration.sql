INSERT INTO focalboard_category_boards(id, user_id, category_id, board_id, create_at, update_at, sort_order)
VALUES
    ('id_1', 'user_id_1', 'category_id_1', 'board_id_1', 0, 0, 0),
    ('id_2', 'user_id_1', 'category_id_2', 'board_id_1', 0, 0, 0),
    ('id_3', 'user_id_1', 'category_id_3', 'board_id_1', 0, 0, 0),
    ('id_4', 'user_id_2', 'category_id_4', 'board_id_2', 0, 0, 0),
    ('id_5', 'user_id_2', 'category_id_5', 'board_id_2', 0, 0, 0),
    ('id_6', 'user_id_3', 'category_id_6', 'board_id_3', 0, 0, 0),
    ('id_7', 'user_id_4', 'category_id_6', 'board_id_4', 0, 0, 0);
