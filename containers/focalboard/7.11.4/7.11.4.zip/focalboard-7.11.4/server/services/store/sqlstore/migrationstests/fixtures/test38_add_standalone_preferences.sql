INSERT INTO focalboard_preferences VALUES
('user-id-1', 'focalboard', 'hiddenBoardIDs', '["board-id-1"]'),
('user-id-2', 'focalboard', 'hiddenBoardIDs', '["board-id-3", "board-id-4"]'),
('user-id-2', 'lorem', 'lorem', ''),
('user-id-2', 'ipsum', 'ipsum', '');