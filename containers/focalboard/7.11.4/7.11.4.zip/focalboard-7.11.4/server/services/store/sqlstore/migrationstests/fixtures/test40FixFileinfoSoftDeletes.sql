INSERT INTO FileInfo
(Id, CreatorId, CreateAt, UpdateAt, DeleteAt)
VALUES
('fileinfo-1', 'user-id', 1, 1, 1000),
('fileinfo-2', 'user-id', 1, 1, 1000),
('fileinfo-3', 'user-id', 1, 1, 0),
('fileinfo-4', 'boards', 1, 1, 2000),
('fileinfo-5', 'boards', 1, 1, 2000),
('fileinfo-6', 'boards', 1, 1, 0);
