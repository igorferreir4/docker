INSERT INTO focalboard_boards
(id, title, type, is_template, channel_id, team_id)
VALUES
('board-id', 'Board', 'O', false, 'linked-channel', 'team-id'),
('template-id', 'Template', 'O', true, 'linked-channel', 'team-id');
