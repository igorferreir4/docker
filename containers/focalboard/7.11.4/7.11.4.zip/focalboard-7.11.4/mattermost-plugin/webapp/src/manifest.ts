// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
import manifest from '../../plugin.json'

export default manifest
export const id = manifest.id
export const version = manifest.version
